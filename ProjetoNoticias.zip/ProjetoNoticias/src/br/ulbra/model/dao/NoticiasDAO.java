/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ulbra.model.dao;

import br.ulbra.connection.ConnectionFactory;
import br.ulbra.model.bean.Noticias;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;

/**
 *
 * @author rhuan
 */
public class NoticiasDAO {
    
         public void save(Noticias noticias) {

        EntityManager em = new ConnectionFactory().getConnection();

        try {
            em.getTransaction().begin();
            
             if(noticias.getId()== null){
               em.persist(noticias);
            }else{
                 em.merge(noticias);
            }
  
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
        
    }
         
          public Noticias remove(Integer id){
              
          EntityManager em = new ConnectionFactory().getConnection();
          Noticias noticias = null;
        try {
           noticias = em.find(Noticias.class, id);
            em.getTransaction().begin();
            em.remove(noticias);
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Removido com sucesso");
        } catch (Exception e) {
            System.err.println(e);
            em.getTransaction().rollback();
        }finally{
            em.close();
        }
        return noticias;
}

        public Noticias findById(Integer id) {

        EntityManager em = new ConnectionFactory().getConnection();
        Noticias noticias = null;

        try {
            noticias = em.find(Noticias.class, id);//passa a classe e o id

        } catch (Exception e) {
            System.err.println(e);

        } finally {
            em.close();

        }
        return noticias;

    }

          public List<Noticias> findAll(){
          EntityManager em = new ConnectionFactory().getConnection();
          List<Noticias> noticias = null;
          try {
            noticias = em.createQuery("from Noticias").getResultList();
            
        } catch (Exception e) {
             System.err.println(e);
           
        }finally{
            em.close();
          }
          return noticias;
    }


}

    

    


