/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ulbra.dao;

import br.ulbra.classes.Lata;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author rhuan
 */
public class LataDAO {

    Connection con;

    public LataDAO() throws SQLException {
        con = ConnectionFactory.getConnection();
    }

    public void create(Lata u) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO tblata (marca,volume,ano,pais,altura,diametro,descricao) VALUES (?,?,?,?,?,?,?)");
            stmt.setString(1, u.getMarca());
            stmt.setString(2, u.getVolume());
            stmt.setString(3, u.getAno());
            stmt.setString(4, u.getPais());
            stmt.setString(5, u.getAltura());
            stmt.setString(6, u.getDiametro());
            stmt.setString(7, u.getDescricao());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Produto Adicionado com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public void delete(Lata u) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM tblata WHERE id = ?");
            stmt.setInt(1, u.getId());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Removido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Remover: " + ex.getMessage());
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public void update(Lata u) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE tbusuario SET marca = ?,volume = ? , ano = ?, pais = ?, altura = ?, diametro = ?, descricao = ? WHERE id = ?");
            stmt.setString(1, u.getMarca());
            stmt.setString(2, u.getVolume());
            stmt.setString(3, u.getAno());
            stmt.setString(4, u.getPais());
            stmt.setString(5, u.getAltura());
            stmt.setString(6, u.getDiametro());
            stmt.setString(7, u.getDescricao());
            stmt.setInt(8, u.getId());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public ArrayList<Lata> read() {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Lata> latas = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM tbUsuario");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Lata lata = new Lata();

                lata.setId(rs.getInt("id"));
                lata.setMarca(rs.getString("marca"));
                lata.setVolume(rs.getString("volume"));
                lata.setAno(rs.getString("ano"));
                lata.setPais(rs.getString("pais"));
                lata.setAltura(rs.getString("altura"));
                lata.setDiametro(rs.getString("diametro"));
                lata.setDescricao(rs.getString("descricao"));

                latas.add(lata);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LataDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return (ArrayList<Lata>) latas;

    }

    public List<Lata> readForDesc(String desc) {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        ArrayList<Lata> latas = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM tblata WHERE marca LIKE ?");
            stmt.setString(1, "%" + desc + "%");

            rs = stmt.executeQuery();

            while (rs.next()) {

                Lata lata = new Lata();

                lata.setId(rs.getInt("id"));
                lata.setMarca(rs.getString("marca"));

                latas.add(lata);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LataDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return latas;

    }

}
